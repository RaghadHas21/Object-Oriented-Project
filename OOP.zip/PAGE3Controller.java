/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author padan
 */
public class PAGE3Controller implements Initializable {

    @FXML
    private Label dateLabel;
    @FXML
    private ComboBox<String> day;
    @FXML
    private ComboBox<String> month;
    @FXML
    private Button back;
    @FXML
    private Button done;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        day.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8", "9",
                "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                "21", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31");

        month.getItems().addAll("JANUARY","FEBRURAY","MARCH","APRIL","MAY","JUNE","JULY",
                "AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER");

        
    }

    @FXML
    private void dayAction(ActionEvent event) {
    }

    @FXML
    private void monthAction(ActionEvent event) {
    }

    @FXML
    private void backAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE2.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            stage.setTitle("Mommy informations");

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void doneAction(ActionEvent event) {
         try {
            inputValidation();
            Mommy user = new Mommy(day.getValue(), (month.getSelectionModel().getSelectedIndex()+1)+"");
            saveToFile(user);
            ((Node) event.getSource()).getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE5.fxml"));
            Parent scene = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(scene));
            stage.show();
            stage.setTitle("Pregnancy informations");

        } catch (Exception io) {
            System.out.println("FXML Loading Error");
        }
    }

    private void inputValidation() throws Exception {

        if (day.getValue() == null || day.getValue().equals("")) {
            JOptionPane.showMessageDialog(null, "Please select a day.");
            throw new Exception();
        }

        if (month.getValue() == null || month.getValue().equals("")) {
            JOptionPane.showMessageDialog(null, "Please select a month.");
            throw new Exception();
        }
    }

    private void saveToFile(Mommy user) {
        try {

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("MommyData.txt"));
            oos.writeObject(user);
            oos.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
