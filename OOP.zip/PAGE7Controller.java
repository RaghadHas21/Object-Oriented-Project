/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author padan
 */
public class PAGE7Controller implements Initializable {

    private Mommy user;

    @FXML
    private Button advice1;
    @FXML
    private Button advice2;
    @FXML
    private Button advice3;
    @FXML
    private Button advice4;
    @FXML
    private Button advice5;
    @FXML
    private Button advice6;
    @FXML
    private Button advice7;
    @FXML
    private Button advice8;
    @FXML
    private Button advice9;
    @FXML
    private TextField helpText1;
    @FXML
    private TextField helpText2;
    @FXML
    private TextField helpText3;
    @FXML
    private TextField helpText4;
    @FXML
    private Button back;
    @FXML
    private Button bye;
    @FXML
    private ImageView ad2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
      
    }

    @FXML
    private void advice1Action(ActionEvent event) {
    }

    @FXML
    private void advice2Action(ActionEvent event) {
    }

    @FXML
    private void advice3Action(ActionEvent event) {
    }

    @FXML
    private void advice4Action(ActionEvent event) {
    }

    @FXML
    private void advice5Action(ActionEvent event) {
    }

    @FXML
    private void advice6Action(ActionEvent event) {
    }

    @FXML
    private void advice7Action(ActionEvent event) {
    }

    @FXML
    private void advice8Action(ActionEvent event) {
    }

    @FXML
    private void advice9Action(ActionEvent event) {
    }

    @FXML
    private void helpText1Action(ActionEvent event) {
    }

    @FXML
    private void helpText2Action(ActionEvent event) {
    }

    @FXML
    private void helpText3Action(ActionEvent event) {
    }

    @FXML
    private void helpText4Action(ActionEvent event) {
    }

    @FXML
    private void backAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE5.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            PAGE5Controller controller5 = loader.getController();
            controller5.setMommyData(user);
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void byeAction(ActionEvent event) {
        System.exit(0);
    }

    void setMommyData(Mommy user) {
        this.user = user;
    }

    @FXML
    private void advice1(MouseEvent event) {
        helpText1.setText("During the first month of your pregnancy, your eyelashes are still longer than your baby’s, who is currently 2 mm. The neural tube is formed, which later turns into the brain and spinal cord, and cells grow from the middle layer that form your baby’s ribs, spine, and muscles stomach later. ");
        helpText2.setText("There are many signs and symptoms of pregnancy in this month, such as: feeling tired and exhausted, frequent urination, feeling nauseous or disgusted with certain foods . ");
        helpText3.setText("There is a group of foods that should be avoided during the first months of pregnancy, as they may cause harm to the fetus and risk to pregnancy, such as: canned and processed food, pineapple, raw and undercooked meat, and caffeine. ");
        helpText4.setText("You will be qualified for this stage, which will be one of the most exciting stages of your life. You are really strong and your child is lucky to have a mother like you.");
    }

    @FXML
    private void advice6(MouseEvent event) {
        helpText1.setText("At this time, your fetus weighs nearly a kilogram, its fingers have become more clear and most importantly its ability to respond to you, whether to your voice or your movement.");
        helpText2.setText("The sixth month begins and your fetus will grow with it, now you may notice an increase in some symptoms such as enlarged feet, back pain and weight gain.");
        helpText3.setText("You should avoid seafood, caffeine, spicy food and fast food.");
        helpText4.setText("That little piece from heaven growing inside of you will be the greatest love of your life.");
    }

    @FXML
    private void advice3(MouseEvent event) {
        helpText1.setText("Your fetus is now about 3 cm long, which is about the size of your nose.  The heart is working regularly now, fingers and toes appear, its spine makes its first move, its brain is growing and lungs are formed, at the end of this month all your baby's basic organs will be formed and most of them start working .");
        helpText2.setText("In this month, pregnancy hormones cause positive changes in your skin, and your face swells. Pregnancy leads to an increase in your weight by 25%, which ranges from 7 to 14 kg. Your heart, kidneys, and lungs are working hard to provide the baby's needs. You will begin to improve and recover from the nausea and dizziness that you have had in the past months . ");
        helpText3.setText("Avoid foods that contain a lot of calories, and foods that contain spices.  Also, do not drink a lot of herbs without consulting your doctor, as there are some that cause abortion, such as cinnamon and fenugreek. ");
        helpText4.setText("You never understand life until it grows inside of you !");
    }

    @FXML
    private void advice9(MouseEvent event) {
        helpText1.setText("The weight of the fetus this month is between 3 and 3.5 kilograms, and its length is between 50 to 55 centimeters.");
        helpText2.setText("The size of the uterus increases due to the increase in the size of the fetus, the level of the abdomen decreases and extends forward, the feeling of heartburn, indigestion and shortness of breath decreases, the feeling of heaviness in the lower abdomen and frequent urination.");
        helpText3.setText("In this month, you should drink a lot of fluids such as cinnamon and ginger, eat a lot of vegetables and eat dates because it facilitates childbirth.");
        helpText4.setText("Congratulation mommy it's time to be the most beautiful mother.");
    }

    @FXML
    private void advice8(MouseEvent event) {
        helpText1.setText("The weight of the fetus became 2.2 kg, and he is still continuing to gain weight, which is not yet complete.");
        helpText2.setText("This month, you will notice an increased feeling of fatigue, frequent urination and anxiety.");
        helpText3.setText("You should avoid caffeine and fried foods. You should try to eat a lot of fruits like Orange, Mango, Apple and Banana.");
        helpText4.setText("Being pregnant means every day is another day closer to meeting the other love of your life.");
    }

    @FXML
    private void advice7(MouseEvent event) {
        helpText1.setText("Your fetus has increased in weight to 1800 grams, it now hears you accurately and responds to light, sound and pain.");
        helpText2.setText("This month, you will notice pelvic pain, constipation and feeling tired.");
        helpText3.setText("You should avoid fast food, caffeine, spicy food and stay away from food with many salts it increases water retention in the body, which increases the swelling of the feet during pregnancy.");
        helpText4.setText("The last trimester of pregnancy has begun, and the longing for your fetus has increased, to see it with your eyes and embrace it.  This third will pass quickly and you will find him next to you.");
    }

    @FXML
    private void advice2(MouseEvent event) {
        helpText1.setText("Your baby has become the size of your thumb nail, his face does not appear clearly defined, but it is possible to distinguish the location of his face. From now on it is called the fetus, as its head becomes more like a human head.  It develops a primary brain, neck, heart, and blood vessels connect him to the best mommy ever.");
        helpText2.setText("It is normal for you to feel general tired or to feel dizzy and nauseous. Try to rest as much as possible because some pregnancy problems and emotions start in this month due to the hormonal changes taking place in your body.");
        helpText3.setText("In this month, you should eat healthy balanced meals, so be sure to avoid eating fast foods, vegetables that are not washed well, in addition to raw foods.");
        helpText4.setText("Remember, sweet mom: your body has given you the greatest gift of your life !");
    }

    @FXML
    private void advice4(MouseEvent event) {
        helpText1.setText("The length of your fetus has reached about 9 cm. This is the main growth stage of your fetus. It grows in size, its organs mature, its hormones escape, its hair and eyebrows appear, and its heart beats vigorously.  Your fetus can now hear the sound of your stomach digesting food, the sound of your heartbeat and even your voice outside. ");
        helpText2.setText("The first stage of pregnancy (the first three months) is over, and now the middle stage of your pregnancy begins and it is more comfortable, you feel energetic and your social relationship with others increases, your heart production increases by 20%. You will feel the first kick of your child! You will be happy with it and it will be very exciting and bring you closer to him.");
        helpText3.setText("It is advised to refrain from eating foods rich in salt, foods rich in sugar, in addition to soft drinks and energy drinks, which are not tolerated by the weak immune system of the mother and may cause a threat to the health of the fetus and mother at the same time.  ");
        helpText4.setText("DO NOT FORGET : A new baby is like the beginning of all things – wonder, hope, a dream of possibilities.");
    }

    @FXML
    private void advice5(MouseEvent event) {
        helpText1.setText("The fifth month of pregnancy is the month of rapid growth , Your fetus is about 18 cm long, and its weight exceeds the weight of the placenta. It can hear sounds outside your body, making it jump sometimes and hit its hands and feet.  ");
        helpText2.setText("You must now feel the baby's movements clearly, your uterus is rising towards your lungs and pushing your belly out, your navel is taking a prominent and flat shape. Buy loose, spacious and elegant clothes because it will raise your spirits. ");
        helpText3.setText("In the fifth month of pregnancy, mom should be careful to eat sufficient quantities of nutrients and materials necessary for the growth of the body and the fetus, such as eating almonds and green leafy vegetables, and reducing as much as possible drinking stimulants that contain caffeine, which leads to digestive disorder and reduces iron absorption, which may affect  It negatively affects the fetus. ");
        helpText4.setText("Dear mom, You are pregnant and you are strong. You are bold and beautiful. Go forth in your boldness, beauty and satisfaction. Trust your body from birth and know that the collective strength of women around the world will be with you.");
    }

}
