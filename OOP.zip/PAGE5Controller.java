/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author padan
 */
public class PAGE5Controller implements Initializable {

    @FXML
    private Button firstMonth;
    @FXML
    private Button secondMonth;
    @FXML
    private Button thirdMonth;
    @FXML
    private Button forthMonth;
    @FXML
    private Button fifthMonth;
    @FXML
    private Button sixthMonth;
    @FXML
    private Button seventhMonth;
    @FXML
    private Button eighthMonth;
    @FXML
    private Button ninthMonth;
    @FXML
    private Button dateOfBirth;
    @FXML
    private Button memories;
    @FXML
    private Button advices;
    @FXML
    private TextField textDateOfBirth;
    @FXML
    private AnchorPane fruit;
    @FXML
    private AnchorPane size;
    @FXML
    private Button back;

    private Mommy user;

    private int date;
    @FXML
    private Label lbl1;
    @FXML
    private Label lbl2;
    @FXML
    private Label lbl3;
    @FXML
    private Label lbl4;
    @FXML
    private Label lbl5;
    @FXML
    private Label lbl6;
    @FXML
    private Label lbl7;
    @FXML
    private Label lbl8;
    @FXML
    private Label lbl9;
    @FXML
    private Label lblSize;
    @FXML
    private ImageView fruitImage;
    @FXML
    private ImageView scaleImage;
    @FXML
    private Label lblSize1;
    @FXML
    private Label lblSize11;
    @FXML
    private Label fruitName;
    @FXML
    private Label lblSize2;
    @FXML
    private StackPane img1;
    @FXML
    private StackPane img2;
    @FXML
    private StackPane img3;
    @FXML
    private StackPane img4;
    @FXML
    private StackPane img5;
    @FXML
    private StackPane img6;
    @FXML
    private StackPane img7;
    @FXML
    private StackPane img8;
    @FXML
    private StackPane img9;
    @FXML
    private Label lblMonth;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadFromFile();
        setData();
    }

 

    @FXML
    private void firstMonthAction(ActionEvent event) {
    }

    @FXML
    private void secondMonthAction(ActionEvent event) {
    }

    @FXML
    private void thirdMonthAction(ActionEvent event) {
    }

    @FXML
    private void forthMonthAction(ActionEvent event) {
    }

    @FXML
    private void fifthMonthAction(ActionEvent event) {
    }

    @FXML
    private void sixthMonthAction(ActionEvent event) {
    }

    @FXML
    private void seventhMonthAction(ActionEvent event) {
    }

    @FXML
    private void eighthMonthAction(ActionEvent event) {
    }

    @FXML
    private void ninthMonthAction(ActionEvent event) {
    }

    @FXML
    private void dateOfBirthAction(ActionEvent event) {

        LocalDate date2 = LocalDate.of(LocalDate.now().getYear(), Integer.parseInt(user.getMonth()), Integer.parseInt(user.getDay()));
        date2 = date2.plusDays(270);

        textDateOfBirth.setText("You will be a MOM on: "+DateTimeFormatter.ofPattern("dd/MM/YYYY").format(date2));

    }

    @FXML
    private void memoriesAction(ActionEvent event) {
        try {
            saveToFile();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE6.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());

            PAGE6Controller controller6 = loader.getController();

            controller6.setMommyData(user);

            stage.setScene(scene);
            stage.setTitle("Memories page");

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void advicesAction(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE7.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            PAGE7Controller controller7 = loader.getController();

            controller7.setMommyData(user);

            stage.setScene(scene);
            stage.setTitle("Advices & Tips");

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void textDateOfBirthAction(ActionEvent event) {
    }

    @FXML
    private void fruitAction(MouseEvent event) {
    }

    @FXML
    private void sizeAction(MouseEvent event) {
    }

    @FXML
    private void backAction(ActionEvent event) {
        try {
            saveToFile();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE2.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            stage.setTitle("Pregnancy informations");

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    public void setMommyDate(String dy, String mn) {

        user = new Mommy(dy, mn);
        setData();

    }

    public void setMommyData(Mommy user) {
        this.user = user;
        setData();
    }

    private void setData() {
        LocalDate date1 = LocalDate.now();
        date1.getYear();

        LocalDate date2 = LocalDate.of(date1.getYear(), Integer.parseInt(user.getMonth()), Integer.parseInt(user.getDay()));

        int days = (int) date2.until(date1, ChronoUnit.DAYS);
        int months = days / 30;
        months++;
        lblMonth.setText("You are in month: " + months);
        updateInformation(months);

    }

    public void updateInformation(int month) {

        lbl1.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl2.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl3.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl4.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl5.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl6.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl7.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl8.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");
        lbl9.setStyle("-fx-text-fill: black; -fx-background-color: ; -fx-background-radius: 20");

        img1.setStyle("");
        img2.setStyle("");
        img3.setStyle("");
        img4.setStyle("");
        img5.setStyle("");
        img6.setStyle("");
        img7.setStyle("");
        img8.setStyle("");
        img9.setStyle("");

        try {
            switch (month) {
                case 1:
                    lbl1.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("0.23cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/sesame.png")));
                    img1.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("sunflowerseeds");
                    break;
                case 2:
                    lbl2.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("1.57cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/blueberry.png")));
                    img2.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("blueraspberry");
                    break;
                case 3:
                    lbl3.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("4.33cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/strawberry.png")));
                    img3.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("strawberry");
                    break;
                case 4:
                    lbl4.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("8.75cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/lemon.png")));
                    img4.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("lemon");
                    break;
                case 5:
                    lbl5.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("14.42cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/orange.png")));
                    img5.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("orange");
                    break;
                case 6:
                    lbl6.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("26cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/pomegranate.png")));
                    img6.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("pomegranate");
                    break;
                case 7:
                    lbl7.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("35.50cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/broccoli.png")));
                    img7.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("broccoli");
                    break;
                case 8:
                    lbl8.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("43.39cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/pineapple.png")));
                    img8.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("pineapple");
                    break;
                case 9:
                    lbl9.setStyle("-fx-text-fill: white; -fx-background-color: black; -fx-background-radius: 20");
                    lblSize.setText("51.60cm");
                    fruitImage.setImage(new Image(new FileInputStream("images/watermelon.png")));
                    img9.setStyle("-fx-border-color: black; -fx-border-width: 3");
                    fruitName.setText("watermelon");
                    break;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PAGE5Controller.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    @FXML
    private void monthSelected(MouseEvent event) {
        updateInformation(Integer.parseInt(((Label) event.getSource()).getText()));
    }

    public void loadFromFile() {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("MommyData.txt"));
            user = (Mommy) ois.readObject();
            ois.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void saveToFile() {
        try {

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("MommyData.txt"));
            oos.writeObject(user);
            oos.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
