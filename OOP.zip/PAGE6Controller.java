/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.activation.MimetypesFileTypeMap;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author padan
 */
public class PAGE6Controller implements Initializable {

    private Mommy user;

    @FXML
    private TextField text1;
    @FXML
    private Button photo1;
    @FXML
    private TextField text4;
    @FXML
    private Button photo4;
    @FXML
    private TextField text2;
    @FXML
    private Button photo2;
    @FXML
    private TextField text5;
    @FXML
    private Button photo5;
    @FXML
    private TextField text3;
    @FXML
    private Button photo3;
    @FXML
    private Button back;
    @FXML
    private ImageView img1;
    @FXML
    private ImageView img4;
    @FXML
    private ImageView img2;
    @FXML
    private ImageView img5;
    @FXML
    private ImageView img3;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void text1Action(ActionEvent event) {
        user.getTexts()[0] = text1.getText();
    }

    @FXML
    private void photo1Action(ActionEvent event) {

        FileChooser fil_chooser = new FileChooser();
        File file = fil_chooser.showOpenDialog(null);
        if (file != null) {
            String mimetype = new MimetypesFileTypeMap().getContentType(file);
            String type = mimetype.split("/")[0];
            if (type.equals("image")) {
                user.getImages()[0] = file.getAbsolutePath();
                updateData();
            } else {
                JOptionPane.showMessageDialog(null, "It's not an image");
            }
        }

    }

    @FXML
    private void text4Action(ActionEvent event) {
        user.getTexts()[3] = text1.getText();

    }

    @FXML
    private void photo4Action(ActionEvent event) {
        FileChooser fil_chooser = new FileChooser();
        File file = fil_chooser.showOpenDialog(null);
        if (file != null) {
            String mimetype = new MimetypesFileTypeMap().getContentType(file);
            String type = mimetype.split("/")[0];
            if (type.equals("image")) {
                user.getImages()[3] = file.getAbsolutePath();
                updateData();
            } else {
                JOptionPane.showMessageDialog(null, "It's not an image");
            }
        }
    }

    @FXML
    private void text2Action(ActionEvent event) {
        user.getTexts()[1] = text1.getText();
    }

    @FXML
    private void photo2Action(ActionEvent event) {
        FileChooser fil_chooser = new FileChooser();
        File file = fil_chooser.showOpenDialog(null);
        if (file != null) {
            String mimetype = new MimetypesFileTypeMap().getContentType(file);
            String type = mimetype.split("/")[1];
            if (type.equals("image")) {
                user.getImages()[0] = file.getAbsolutePath();
                updateData();
            } else {
                JOptionPane.showMessageDialog(null, "It's not an image");
            }
        }
    }

    @FXML
    private void text5Action(ActionEvent event) {
        user.getTexts()[4] = text1.getText();
    }

    @FXML
    private void photo5Action(ActionEvent event) {
        FileChooser fil_chooser = new FileChooser();
        File file = fil_chooser.showOpenDialog(null);
        if (file != null) {
            String mimetype = new MimetypesFileTypeMap().getContentType(file);
            String type = mimetype.split("/")[0];
            if (type.equals("image")) {
                user.getImages()[4] = file.getAbsolutePath();
                updateData();
            } else {
                JOptionPane.showMessageDialog(null, "It's not an image");
            }
        }
    }

    @FXML
    private void text3Action(ActionEvent event) {
        user.getTexts()[2] = text1.getText();
    }

    @FXML
    private void photo3Action(ActionEvent event) {
        FileChooser fil_chooser = new FileChooser();
        File file = fil_chooser.showOpenDialog(null);
        if (file != null) {
            String mimetype = new MimetypesFileTypeMap().getContentType(file);
            String type = mimetype.split("/")[0];
            if (type.equals("image")) {
                user.getImages()[2] = file.getAbsolutePath();
                updateData();
            } else {
                JOptionPane.showMessageDialog(null, "It's not an image");
            }
        }
    }

    @FXML
    private void backAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE5.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            PAGE5Controller controller5 = loader.getController();

            controller5.setMommyData(user);
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    public void setMommyData(Mommy user) {
        this.user = user;

        updateData();

    }

    private void updateData() {
        try {
            img1.setImage(new Image(new FileInputStream(user.getImages()[0])));
            text1.setText(user.getTexts()[0]);
        } catch (Exception e) {
        }
        try {
            img2.setImage(new Image(new FileInputStream(user.getImages()[1])));
            text2.setText(user.getTexts()[1]);
        } catch (Exception e) {
        }
        try {
            img3.setImage(new Image(new FileInputStream(user.getImages()[2])));
            text3.setText(user.getTexts()[2]);
        } catch (Exception e) {
        }
        try {
            img4.setImage(new Image(new FileInputStream(user.getImages()[3])));
            text4.setText(user.getTexts()[3]);
        } catch (Exception e) {
        }
        try {
            img5.setImage(new Image(new FileInputStream(user.getImages()[4])));
            text5.setText(user.getTexts()[4]);
        } catch (Exception e) {
        }

    }

}
