/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.Serializable;
import javax.swing.JComboBox;

/**
 *
 * @author padan
 */
public class Mommy implements Serializable {

    private String day, month;
    private String[] images, texts;
    private JComboBox monthBox;

    public Mommy(String day, String month) {
        this.day = day;
        this.month = month;
        images = new String[5];
        texts = new String[5];
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDay() {
        return day;
    }

    public String getMonth() {
        return month ;
    }

    public String[] getImages() {
        return images;
    }

    public void setImages(String[] images) {
        this.images = images;
    }

    public String[] getTexts() {
        return texts;
    }

    public void setTexts(String[] texts) {
        this.texts = texts;
    }

}
