/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package himommy;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author padan
 */
public class PAGE2Controller implements Initializable {

    @FXML
    private TextField textName;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void noAction(ActionEvent event) {
        try {
            inputValidation();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE4.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            stage.setTitle("Mommy's informations");

        } catch (Exception io) {
            System.out.println("FXML Loading Error");
        }

    }

    @FXML
    private void yesAction(ActionEvent event) {
        try {
            inputValidation();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PAGE3.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (Exception io) {
            System.out.println("FXML Loading Error");
        }

    }


    @FXML
    private void nameAction(ActionEvent event) {
        try {
            inputValidation();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    
    private boolean vaildationName() {
        return textName.getText().matches("([a-zA-z]+|[a-zA-z]\\s[a-zA-z]+)") && !textName.getText().trim().isEmpty();
    }

    private void inputValidation() throws Exception {
        if (!vaildationName()) {
            JOptionPane.showMessageDialog(null, "Invalid name try again");
            textName.setText("");
            throw new Exception("Invalid name");
        }
    }
}
